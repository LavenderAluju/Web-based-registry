from enum import unique
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.db import transaction
from .models import User, Admin, Patient, Diagnostic



GENDER_CHOICES = (
    ("1", "Male"),
    ("2", "Female"),
)

MARITAL_CHOICES = (
    ("1", "single"),
    ("2", "Married"),
    ("3", "Engaged")
)

DISEASE_STATUS_CHOICES = (
    ("1", "Active"),
    ("2", "InActive"),
    ("3", "Recoverd")
)

EMP = (
    ("1", "Yes"),
    ("2", "No")
)

class AdminSignUpForn(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    phone_number = forms.CharField(required=True)
    location = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User
        fields = [ "username", 'first_name', 'last_name', 'email', 'phone_number', 'location', "password1", "password2"]

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_admin = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.save()
        agent = Admin.objects.create(user=user)
        agent.phone_number = self.cleaned_data.get('phone_number')
        agent.location = self.cleaned_data.get('location')
        agent.save()

        return agent

class NormalSignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    phone_number = forms.CharField(required=True)
    occupation = forms.CharField(required=True)

    class Meta(UserCreationForm):
        model = User
        fields = '__all__'
    
    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_agent = True
        user.is_tenant = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.save()
        tenant = Normal.objects.create(user=user, username="1")
        tenant.phone_number = self.cleaned_data('phone_number')
        tenant.occupation = self.cleaned_data('occupation')
        tenant.save()

        return tenant

class PatientForm(forms.Form):
    first_name = forms.CharField(label='first name', max_length=100) 
    second_name = forms.CharField(label='last name', max_length=100)
    phone_number = forms.CharField(label='contact', max_length=100)
    email = forms.EmailField()
    age = forms.IntegerField(label='age')
    national_id = forms.CharField(max_length=30, label='National Id/Birth Certificate Number')
    sex = forms.ChoiceField(choices=GENDER_CHOICES)
    occupation = forms.CharField(max_length=20)
    place_of_birth = forms.CharField(max_length=50)
    date_birth = forms.DateField()
    marital = forms.ChoiceField(choices=MARITAL_CHOICES)
    home_address = forms.CharField(max_length=30)
    reason = forms.CharField(widget=forms.Textarea(attrs={'name':'body', 'rows':7, 'cols':5}))


