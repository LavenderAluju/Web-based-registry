from email.policy import default
from django.contrib.auth.models import AbstractUser
from django.db import models
import random
import string


class User(AbstractUser):
    is_admin = models.BooleanField(default=False)
    is_normal = models.BooleanField(default=False)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)

class Admin(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    phone_number = models.CharField(max_length=15)
    location = models.CharField(max_length=20)

class Patient(models.Model):
    patient_id = models.CharField(max_length=20, unique=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15, unique=True)
    email = models.EmailField(unique=True)
    age = models.IntegerField()
    national_id = models.CharField(max_length=40, unique=True)
    sex = models.CharField(max_length=10)
    occupation = models.CharField(max_length=20)
    place_of_birth = models.CharField(max_length=50)
    date_birth = models.DateField()
    marital = models.CharField(max_length=10)
    employment = models.CharField(max_length=10)
    home_address = models.CharField(max_length=30)
    reason_for_adm = models.CharField(max_length=200)

class Diagnostic(models.Model):
    ID = models.ForeignKey(Patient, on_delete=models.CASCADE)
    disease = models.CharField(max_length=100)
    date = models.DateField()
    disease_status = models.CharField(max_length=10)

    