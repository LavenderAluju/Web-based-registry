from django.urls import path
from .import  views

urlpatterns=[
    
     path('home/',views.detailspage, name='home'),
     path('add/',views.homepage, name='add'),
     path('',views.AdminRegister.as_view(), name='customer_register'),
     path('login/',views.login_request, name='login'),
     path('logout/',views.logout_view, name='logout'),
]