from django.contrib.auth import login, logout,authenticate
from django.shortcuts import redirect, render
from django.contrib import messages
from django.views.generic import CreateView
from .form import AdminSignUpForn, NormalSignUpForm, PatientForm
from django.contrib.auth.forms import AuthenticationForm
from .models import User, Patient
from django.http import HttpResponse, HttpResponseNotFound
import random, string
from django.contrib.auth.decorators import login_required


def patient_id_generator(size=11, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

@login_required(login_url="login")
def homepage(request):
        # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = PatientForm(request.POST)
        # check whether it's valid:
        if form.is_valid():

            fname = form.cleaned_data.get("first_name")
            sname = form.cleaned_data.get("second_name")
            nation = form.cleaned_data.get("national_id")
            email = form.cleaned_data.get("email")
            contact = form.cleaned_data.get("phone_number")
            age = form.cleaned_data.get("age")
            pbirth = form.cleaned_data.get("place_of_birth")
            dbith = form.cleaned_data.get("date_birth")
            home = form.cleaned_data.get("home_address")
            sex = form.cleaned_data.get("sex")
            marital = form.cleaned_data.get("marital")
            occup = form.cleaned_data.get("occupation")
            reason = form.cleaned_data.get("reason")
            
            patient = Patient.objects.create(patient_id=patient_id_generator(),first_name = fname, 
                        last_name = sname, national_id =nation, email = email, phone_number = contact,
                        age = age, place_of_birth = pbirth,  date_birth = dbith, home_address = home, 
                        sex = sex, marital = marital, occupation = occup, reason_for_adm = reason)

            patient.save()

            return HttpResponse('Patient Added succefully')
        else:
            print(form.errors)

    # if a GET (or any other method) we'll create a blank form
    else:
        form = PatientForm()
    return render(request, 'index.html', {'form': form})

@login_required(login_url="login")
def detailspage(request):

    patient = Patient.objects.all()
    return render(request, 'home.html', {"patient": patient})


class AdminRegister(CreateView):
    model = User
    form_class = AdminSignUpForn
    template_name = '/home/alan/project/web/pages/templates/customer_register.html'

    def form_valid(self, form):
        user = form.save()
        #login(self.request, user)
        return redirect('login')


def login_request(request):
    if request.method=='POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None :
                login(request,user)
                return redirect('home')
            else:
                messages.error(request,"Invalid username or password")
        else:
                messages.error(request,"Invalid username or password")
    return render(request, 'login.html',
    context={'form':AuthenticationForm()})

def logout_view(request):
    logout(request)
    return redirect('/')